# Scale-Invariant Simplicial $R^2$ Inflation, Multi-Sector $CP$ Structure, and Zero-Parameter Non-Thermal Scalaron Leptogenesis from a Tetrahedral $\mathrm{Spin}(10)$ Threshold

**Author:** Jozsef Olcsak (ORCID: `0009-0003-7311-6522`)  
**Archive DOI:** `10.5281/zenodo.24380371` (Concept DOI: `10.5281/zenodo.24379737`)  
**Version:** `v1.2.0` (`k_added = 0` added free parameters)

## Package Contents
- `main.tex` & `Sub5_JCAP_Starobinsky_Seesaw_and_NonThermal_Leptogenesis.pdf` — Self-contained manuscript in standard curved-space QFT and cosmological notation (`v1.2.0`).
- `figures/` — Publication figures (`fig1_starobinsky_k4_inflation_and_cmb_contours_en.pdf/.png` and `fig2_boltzmann_reheating_leptogenesis_and_cp_tests_en.pdf/.png`).
- `supplementary_code_and_data/verify_paper24_starobinsky_seesaw_leptogenesis.py` — Standalone symbolic (`SymPy`) and stiff numerical (`SciPy DOP853/Radau`) verification suite reproducing all theorems, NLO CMB observables, `SymPy`-derived 2-flavor and 3-flavor spectator matrices $C^{(\ell+H)}$, unflavored/2-flavor/3-flavor Boltzmann integrations, and non-minimal Higgs $\xi_H$ pinning in ~14 seconds.
- `supplementary_code_and_data/generate_paper24_figures.py` — Standalone script regenerating all figures directly from the ODE solvers.

## Standalone Reproducibility
From the root of this unzipped directory:
```bash
python3 supplementary_code_and_data/verify_paper24_starobinsky_seesaw_leptogenesis.py
python3 supplementary_code_and_data/generate_paper24_figures.py
pdflatex main.tex && pdflatex main.tex
```
